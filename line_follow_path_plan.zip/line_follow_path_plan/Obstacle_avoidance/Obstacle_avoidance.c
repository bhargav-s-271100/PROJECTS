/*
 *	Obstacle_Avoidance.c
 *
 * Created: 08-04-2020 13:22:40
 *  Author: Bhargav under the guidance team Mooc E-yantra
 */ 
//-------------------------------------------------------------------------------------------------------------
//-----------------------------------ADDITIONAL PART-----------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------
#include <avr/io.h>						//Standard AVR input-output library
#include <util/delay.h>							// Standard AVR Delay Library
#include "Week4_Macros_definitions.h"
#include <stdbool.h>					// Standard C Library for Boolean Type
#include <avr/interrupt.h>
//-------------------------------------------------------------------------------------------------------------

// Global Variable declaration

unsigned char sensor_data;	// To store data of left, center and right IR sensors
unsigned char left_sensor, right_sensor, center_sensor, sensor_data;  // To store data of left, center and right White line sensors
unsigned char prev_sensor_data;

unsigned long pulse;			//to store the number of echo pulses
unsigned int obstacle;
//-----------------------------------------------------------------------------------------------------------

/**
 * @brief      Function to configure pins of ATmega2560 to which pins of L293D Motor Driver IC is connected
 */
void motors_pin_config(void) {

	motors_dir_ddr_reg |= (1<<motors_RB_pin | 1<<motors_LB_pin | 1<<motors_LF_pin | 1<<motors_RF_pin) ;			// set **ONLY** motor pins as output
	motors_dir_port_reg &= ~(1<<motors_RB_pin | 1<<motors_RF_pin | 1<<motors_LB_pin | 1<<motors_LF_pin) ;			// stop motors initially
}

/**
 * @brief      Function to configure left and right channel pins of the L293D Motor Driver IC for PWM
 */
void pwm_pin_config(void){

	motors_pwm_ddr_reg |= ( 1<<motors_pwm_R_pin | 1<<motors_pwm_L_pin ) ;		// set **ONLY** left and right channel pin as output
	motors_pwm_port_reg |= ( 1<<motors_pwm_R_pin | 1<<motors_pwm_L_pin ) ;		// enable left and right channel
}


//-------------------
/**
 * @brief      Function to initialize Timer 5 in Phase Correct PWM mode for speed control of motors of Firebird-V
 *
 */
void timer_pwm_init(void) {

	// Set Non Inverting Output Compare Mode using COMn1 and COMn0 as 10
	// Configure for 8 bit Phase correct PWM mode
	TCCR0A_reg = (TCCR0A_reg | (1<<COM0B1_bit | 1<<WGM0_0_bit)) & ~(1<<COM0B0_bit | 1<<WGM0_1_bit) ;

	// Configure for Phase Correct PWM
	// Set Prescalar to 64
	TCCR0B_reg = (TCCR0B_reg | ( 1<<CS0_0_bit | 1<<CS0_1_bit)) & ~(1<<WGM0_2_bit | 1<<CS0_2_bit) ;

	// Initialize Timer/counter register as 0
	TCNT0_reg = 0x00 ;

	// Set Non Inverting Output Compare Mode using COMn1 and COMn0 as 10
	// Configure for 8 bit Phase correct PWM mode
	TCCR2A_reg = (TCCR2A_reg | (1<<COM2B1 | 1<<WGM2_0_bit)) & ~(1<<COM2B0 | 1<<WGM2_1_bit) ;

	// Configure for Phase Correct PWM
	// Set Prescalar to 64
	TCCR2B_reg = (TCCR2B_reg | ( 1<<CS2_0_bit | 1<<CS2_1_bit)) & ~(1<<WGM2_2_bit | 1<<CS2_2_bit) ;

	// Initialize Timer/counter register as 0
	TCNT2_reg = 0x00 ;

	// Initialize OCR registers as 0
	OCR0B_reg = 0xFF ;
	OCR2B_reg = 0xFF ;

}

/**
 * @brief      Function to control the speed of both the motors of turtle bot
 *
 * @param[in]  left_motor   Left motor speed 0 to 255
 * @param[in]  right_motor  Right motor speed 0 to 255
 */
void set_duty_cycle(unsigned char dcycle_pin_a, unsigned char dcycle_pin_b) {
	OCR2B_reg = dcycle_pin_a  ;
	OCR0B_reg = dcycle_pin_b ;
}

/**
 * @brief      Function to make turtle bot move forward.
 */
void motors_move_forward(void) {

	// Set RF and LF, reset RB and LB
	motors_dir_port_reg = (motors_dir_port_reg | (1<<motors_RF_pin | 1<<motors_LF_pin)) & ~(1<<motors_LB_pin | 1<<motors_RB_pin) ;
}

/**
 * @brief      Function to make turtle bot stop.
 */
void motors_stop(void) {

	// reset RB and LB, RF and LF
	motors_dir_port_reg &= ~(1<<motors_RB_pin | 1<<motors_LB_pin | 1<<motors_LF_pin | 1<<motors_RF_pin) ;
	set_duty_cycle(0,0);
}

/**
 * @brief      Makes three WL sensor pins as input and deactivates pull-up for these sensor pins
 */
void WL_sensors_port_config(void){

	left_center_WL_sensors_ddr_reg	&= ~((1<<left_WL_sensor_pin)|(1<<center_WL_sensor_pin)) ;
	right_WL_sensors_ddr_reg &= ~(1<<right_WL_sensor_pin);

	left_center_WL_sensors_port_reg	 &= ~((1<<left_WL_sensor_pin)|(1<<center_WL_sensor_pin)) ;
	right_WL_sensors_port_reg &= ~(1<<right_WL_sensor_pin);
}

/**
 * @brief      reads the status of 3 sensors as 1 for black and 0 for white and combines it into variable sensor data
 *
 **/
void WL_sensors_read_data(void)
{
	// Sets value as 1 if sensor detects black color else 0
	left_sensor		= ((left_center_WL_sensors_pin_reg & (1<<left_WL_sensor_pin)) == (1<<left_WL_sensor_pin)) ? 1 : 0;
	center_sensor	= ((left_center_WL_sensors_pin_reg & (1<<center_WL_sensor_pin)) == (1<<center_WL_sensor_pin)) ? 1 : 0;
	right_sensor	= ((right_WL_sensors_pin_reg & (1<<right_WL_sensor_pin)) == (1<<right_WL_sensor_pin)) ? 1 : 0;

	sensor_data		= ((left_sensor<<2) | (center_sensor<<1)  | right_sensor);

}

/**
 * @brief      Makes trigger pin of ultra-sonic sensor as output and echo pin as input and also turns on pull-up resistor for echo pin
 */

void sensor_config(void)
{
	//configuring trigger pin as output,echo pin as input and turn on pull-up resistor for echo pin
	US_ddr_reg = ((US_ddr_reg | 1<<trigger_pin) & ~(1<<echo_pin));
	US_port_reg |= 1<<echo_pin;

}

/**
 * @brief      Configures External Interrupt on the echo pin
 */
void echo_interrupt_config(void) 
{

	// all interrupts have to be disabled before configuring interrupts
	cli();	// Disables Interrupts Globally
	
	// Turn ON INT1 (alternative function of PB1 i.e echo Pin)
	EIMSK_reg |= 1<<echo_pin ;
	
	// Negative edge detection on INT1
	EICRA_reg = ((EICRA_reg | 1<<ISC1_bit) & ~(1<<ISC0_bit))  ;
	
	sei();	// Enable Interrupts Globally
}

/**
 * @brief      Interrupt service routine for interrupt generated by echo pin
 */
ISR(echo_isr_vect)
{
	pulse++;
}

/**
 * @brief      send a high pulse to trigger pin for 15us
 */
void trigger_pulse(void)
{
	//setting trigger high for 15us
	US_port_reg |= 1<<trigger_pin;
	_delay_us(15);
	US_port_reg &= 1<<trigger_pin;
	
}

/**
 * @brief      Makes the turtle bot avoid an obstacle and come back to its path
 */
void avoid_obstacle(void)
{
	set_duty_cycle(200,0);
	_delay_ms(15000);
	set_duty_cycle(200,200);
	_delay_ms(15000);

	set_duty_cycle(80,200);
	_delay_ms(5000);
	set_duty_cycle(0,200);
	_delay_ms(10000);
	set_duty_cycle(80,200);
	_delay_ms(2000);

	set_duty_cycle(200,200);
	_delay_ms(17000);

	set_duty_cycle(0,200);
	_delay_ms(8000);
	set_duty_cycle(200,200);
	_delay_ms(12000);
	
	motors_dir_port_reg = (motors_dir_port_reg | (1<<motors_LB_pin | 1<<motors_RF_pin))& ~(1<<motors_RB_pin | 1<<motors_LF_pin);
	set_duty_cycle(200,100);
	_delay_ms(15000);
	
	motors_move_forward();
	set_duty_cycle(200,100);
	_delay_ms(1000);
	
}

/**
 * @brief      Makes the turtle bot to follow a black line and avoid any intermediate obstacle 
 */
void line_follow_and_avoid(void)
{
	if(pulse>5000 && obstacle==0){
		avoid_obstacle();
		obstacle++;
		pulse=0;
	}
	
	else if(sensor_data==0x00 || sensor_data==0x07)
		sensor_data == prev_sensor_data;

	else if ((sensor_data==0x02) || (sensor_data==0x05))
	set_duty_cycle(200,200);

	else if(sensor_data==0x01)
	set_duty_cycle(200,70);

	else if(sensor_data==0x03)
	set_duty_cycle(200,90);

	else if(sensor_data==0x04)
	set_duty_cycle(70,200);

	else if(sensor_data==0x06)
	set_duty_cycle(90,200);

	prev_sensor_data = sensor_data;
}


//---------------------------------- MAIN ----------------------------------------------------------------
/**
 * @brief      Main function
 *
 * @details    First initializes 3 line sensors, motors and timers for 8-bit Fast PWM mode
 * 			   then make the robot traverse from START to GOAL based on the path input array
 *
 * @return     0
 */
int main(void)
{
	sensor_config();
	echo_interrupt_config();
	
	WL_sensors_port_config();

	pwm_pin_config();			// Initialize pwm pins as output
	timer_pwm_init();			// Initialize Timer

	motors_pin_config();		// Initialize motor pins
	
	motors_move_forward();
    while (1)
    {
		WL_sensors_read_data();
		
		line_follow_and_avoid();
	}
}
//-------------------------------------------------------------------------------------------------------
