var searchData=
[
  ['prev_5fsensor_5fdata_12',['prev_sensor_data',['../Obstacle__avoidance_8c.html#a8b56b173a927d44fdb1c5d57ef4fb097',1,'Obstacle_avoidance.c']]],
  ['pulse_13',['pulse',['../Obstacle__avoidance_8c.html#a9e0bb506e15ff9b9710c1ae36cbd983c',1,'Obstacle_avoidance.c']]],
  ['pwm_5fpin_5fconfig_14',['pwm_pin_config',['../Obstacle__avoidance_8c.html#a8bc06248f8f84533bb53fbbbfe2e7420',1,'Obstacle_avoidance.c']]]
];
