var searchData=
[
  ['sensor_5fconfig_16',['sensor_config',['../Obstacle__avoidance_8c.html#aaaf0030fbcc7d9d100e0e4a53e903780',1,'Obstacle_avoidance.c']]],
  ['sensor_5fdata_17',['sensor_data',['../Obstacle__avoidance_8c.html#a468606c353e179e0b4a41919345c858a',1,'Obstacle_avoidance.c']]],
  ['set_5fduty_5fcycle_18',['set_duty_cycle',['../Obstacle__avoidance_8c.html#a21fc41e97287768d453c56ea7c625fba',1,'Obstacle_avoidance.c']]]
];
