var searchData=
[
  ['timer_5fpwm_5finit_37',['timer_pwm_init',['../Obstacle__avoidance_8c.html#a2142c3e44cf9a7e0dafea424dc93e1f9',1,'Obstacle_avoidance.c']]],
  ['trigger_5fpulse_38',['trigger_pulse',['../Obstacle__avoidance_8c.html#a4bb11dc30af412aab90b891021dc9704',1,'Obstacle_avoidance.c']]]
];
