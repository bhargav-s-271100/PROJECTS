/*
 * Week4_Macros_definitions.h
 *
 * Created: 19/03/2020 23:20
 * Author: Bhargav.S under the guidance of team MOOC E-Yantra
 */ 


#ifndef Week4_Macros_definitions_H_
#define Week4_Macros_definitions_H_


#include <avr/io.h>									// Standard AVR IO Library




// Definitions for ATmega328P micro-controller for sample projects in Proteus Demonstration
#if defined(__AVR_ATmega328P__)
	
	#define F_CPU						16000000
//	Definitions for lcd_special_char project

	#define lcd_data_ddr_reg			DDRD
	#define lcd_control_ddr_reg			DDRB

	#define lcd_data_port_reg			PORTD
	#define lcd_control_port_reg		PORTB

	#define RS_pin						PB0			// PB0	( IO8 )
	#define RW_pin						PB2			// PB2	( IO10 )
	#define EN_pin						PB1			// PB1	( IO9 )

	#define DB7_pin						PD7			// PD7	( IO7 )
	#define DB6_pin						PD6			// PD6	( IO6 )
	#define DB5_pin						PD5			// PD5	( IO5 )
	#define DB4_pin						PD4			// PD4	( IO4 )
	
//	Definitions for line_follow_path_plan project
	
	// 3 IR sensors definitions
	#define		left_center_WL_sensors_ddr_reg				DDRB
	#define		left_center_WL_sensors_port_reg			    PORTB
	#define     left_center_WL_sensors_pin_reg				PINB
	#define		right_WL_sensors_ddr_reg					DDRC
	#define		right_WL_sensors_port_reg					PORTC
	#define     right_WL_sensors_pin_reg					PINC
	#define		left_WL_sensor_pin							PB3
	#define		center_WL_sensor_pin						PB4
	#define		right_WL_sensor_pin							PC0
	
	// Motor enable registers and pins
	#define		motors_pwm_ddr_reg				DDRD
	#define		motors_pwm_port_reg				PORTD
	#define		motors_pwm_L_pin				PD5			// 5
	#define		motors_pwm_R_pin				PD3			// 3
	
	// Motor direction registers and pins
	#define		motors_dir_ddr_reg				DDRD
	#define		motors_dir_port_reg				PORTD
	#define 	motors_LB_pin					PD7			// 7
	#define 	motors_LF_pin					PD6			// 6
	#define 	motors_RF_pin					PD2			// 4
	#define 	motors_RB_pin					PD4			// 2

	// Timer / Counter registers
	// In the case of the ATmega328P used in the Proteus Experiment OCR0 is a 8-bit timer, hence this strategy has been implemented
	#define		OCR2B_reg						OCR2B		// Output Compare Register 2B
	#define		OCR0B_reg						OCR0B		// Output Compare Register 0B
	#define		TCCR0A_reg						TCCR0A		// Timer / Counter Control Register 0A	
	#define		TCCR0B_reg						TCCR0B		// Timer / Counter Control Register 0B
	#define		TCCR2A_reg						TCCR2A		// Timer / Counter Control Register 2A
	#define		TCCR2B_reg						TCCR2B		// Timer / Counter Control Register 2B
	#define		TCNT0_reg						TCNT0		// Timer / Counter 0 Byte register
	#define		TCNT2_reg						TCNT2		// Timer / Counter 2 Byte register

	// Bits of compare output mode in the TCCRnA register ( Timer / Counter 'n' Control Register A, where n = 0, 1, 2 )
	#define		COM2B1_bit						COM2B1
	#define		COM2B0_bit						COM2B0
	#define		COM0B1_bit						COM0B1
	#define		COM0B0_bit						COM0B0
	
	// Bits of waveform generation mode in the TCCRnA and TCCRnB register ( Timer / Counter 'n' Control Register A/B, where n = 0, 1, 2)
	#define		WGM0_0_bit						WGM00		// 0	( Waveform Generation Mode bit 0 )
	#define		WGM0_1_bit						WGM01		// 1	( Waveform Generation Mode bit 1 )
	#define		WGM0_2_bit						WGM02		// 2	( Waveform Generation Mode bit 2 )

	#define		WGM2_0_bit						WGM20		// 0	( Waveform Generation Mode bit 0 )
	#define		WGM2_1_bit						WGM21		// 1	( Waveform Generation Mode bit 1 )
	#define		WGM2_2_bit						WGM22		// 2	( Waveform Generation Mode bit 2 )

	// Bits of clock select mode in the TCCRnB register ( Timer / Counter 'n' Control Register B, where n = 0, 1, 2, 3)
	#define		CS0_0_bit							CS00		// 0	( Clock Select bit 0 )
	#define		CS0_1_bit							CS01		// 1	( Clock Select bit 1 )
	#define		CS0_2_bit							CS02		// 2	( Clock Select bit 2 )
	
	#define		CS2_0_bit							CS20		// 0	( Clock Select bit 0 )
	#define		CS2_1_bit							CS21		// 1	( Clock Select bit 1 )
	#define		CS2_2_bit							CS22		// 2	( Clock Select bit 2 )
	
	
	#define		BAUD_RATE						9600		// Baud rate setting
	
	//macros for additional part : ultrasonic sensor
	#define US_ddr_reg				DDRB
	#define US_port_reg				PORTB
	#define US_pin_reg				PINB
	
	#define trigger_pin				PB0
	#define echo_pin				PB1
	
	#define echo_isr_vect					    INT1_vect
	#define EIMSK_reg							EIMSK
	#define EICRA_reg							EICRA
	#define ISC1_bit							ISC11
	#define ISC0_bit							ISC10

#endif


#endif 