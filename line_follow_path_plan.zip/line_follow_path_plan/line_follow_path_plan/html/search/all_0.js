var searchData=
[
  ['center_5fsensor_0',['center_sensor',['../line__follow__path__plan_8c.html#a841a02ad283757bffe44e36050ec0129',1,'line_follow_path_plan.c']]],
  ['current_5fcol_1',['current_col',['../line__follow__path__plan_8c.html#a2f742ae1fc0cd4102d57114c85eda9ee',1,'line_follow_path_plan.c']]],
  ['curve_5ffollow_2',['curve_follow',['../line__follow__path__plan_8c.html#a3f361f4d4dfb8dfd1a932d14a7f29781',1,'line_follow_path_plan.c']]]
];
