var searchData=
[
  ['center_5fsensor_46',['center_sensor',['../line__follow__path__plan_8c.html#a841a02ad283757bffe44e36050ec0129',1,'line_follow_path_plan.c']]],
  ['current_5fcol_47',['current_col',['../line__follow__path__plan_8c.html#a2f742ae1fc0cd4102d57114c85eda9ee',1,'line_follow_path_plan.c']]]
];
